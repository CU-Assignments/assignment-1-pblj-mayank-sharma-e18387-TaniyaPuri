import java.util.Scanner;

public class MatrixOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[][] mat1 = new int[2][2];
        int[][] mat2 = new int[2][2];
        int[][] result = new int[2][2];

        System.out.println("Enter Matrix 1 (2x2):");
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                mat1[i][j] = sc.nextInt();

        System.out.println("Enter Matrix 2 (2x2):");
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                mat2[i][j] = sc.nextInt();

        // Addition
        System.out.println("Addition:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                result[i][j] = mat1[i][j] + mat2[i][j];
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }

        // Subtraction
        System.out.println("Subtraction:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                result[i][j] = mat1[i][j] - mat2[i][j];
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }

        // Multiplication
        System.out.println("Multiplication:");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                result[i][j] = 0;
                for (int k = 0; k < 2; k++) {
                    result[i][j] += mat1[i][k] * mat2[k][j];
                }
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
    }
}

