# Assignment 1 - Java Basics

## ✅ Topics Covered:
- Introduction to Java
- Difference between C++ and Java
- Keywords, Tokens, Data Types
- Use of `public`, `private`, and `protected`

## 📝 Problem Statements

### 🔹 Problem 1: String Analysis (Easy Level)
**Objective:**  
Write a Java program to analyze a user-input string. The program should count the number of:
- Vowels
- Consonants
- Digits
- Special characters

### 🔹 Problem 2: Matrix Operations (Medium Level)
**Objective:**  
Write a Java program to perform addition, subtraction, and multiplication on two 2x2 matrices. The program should:
- Accept two matrices from the user
- Validate dimensions
- Perform all 3 operations

### 🔹 Problem 3: Basic Banking System (Hard Level)
**Objective:**  
Create a basic banking system with:
- Account creation (Name, Account Number, Balance)
- Deposit and withdrawal operations
- Balance check before withdrawal
- Encapsulation using private fields and public methods

---

## 🛠 Requirements
- Java 8 or above
- IDE (Eclipse / IntelliJ / VS Code)
- Ubuntu / Linux environment

---

## 📁 Folder Structure

